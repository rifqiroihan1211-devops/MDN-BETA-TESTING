// MDN - Masjid Digital Network
// JavaScript for Interactions and Animations

// ============================
// LOADING SCREEN
// ============================
window.addEventListener('load', function() {
    const loadingScreen = document.getElementById('loadingScreen');
    const body = document.body;
    
    // Add loading class to body
    body.classList.add('loading');
    
    // Hide loading screen after everything is loaded
    setTimeout(function() {
        loadingScreen.classList.add('hidden');
        body.classList.remove('loading');
        
        // Remove loading screen from DOM after animation
        setTimeout(function() {
            loadingScreen.style.display = 'none';
        }, 500);
    }, 1000); // Adjust delay as needed
});

document.addEventListener('DOMContentLoaded', function() {
    
    // ============================
    // HERO SLIDER FUNCTIONALITY
    // ============================
    
    const heroSlider = {
        currentSlide: 0,
        slides: [],
        autoplayInterval: null,
        autoplayDelay: 5000,
        
        init: function() {
            this.loadSlides();
            this.setupControls();
            this.startAutoplay();
        },
        
        loadSlides: async function() {
            try {
                const response = await fetch('api/get-sliders.php');
                const data = await response.json();
                
                if (data.success && data.sliders.length > 0) {
                    this.slides = data.sliders;
                    this.renderSlides();
                    this.renderDots();
                } else {
                    // Use default slide if no sliders found
                    this.useDefaultSlide();
                }
            } catch (error) {
                console.log('Using default slide');
                this.useDefaultSlide();
            }
        },
        
        useDefaultSlide: function() {
            // Keep the default static background
            const sliderContainer = document.getElementById('heroSlider');
            if (sliderContainer) {
                sliderContainer.innerHTML = `
                    <div class="slider-item active">
                        <div class="slider-bg" style="background: linear-gradient(135deg, rgba(26, 95, 63, 0.9), rgba(13, 61, 40, 0.9)), url('data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 viewBox=%270 0 1920 1080%27%3E%3Crect fill=%27%231a5f3f%27 width=%271920%27 height=%271080%27/%3E%3C/svg%3E') center/cover;"></div>
                    </div>
                `;
            }
            // Hide controls if only one slide
            document.querySelector('.slider-controls').style.display = 'none';
            document.querySelector('.slider-dots').style.display = 'none';
        },
        
        renderSlides: function() {
            const sliderContainer = document.getElementById('heroSlider');
            sliderContainer.innerHTML = '';
            
            this.slides.forEach((slide, index) => {
                const slideElement = document.createElement('div');
                slideElement.className = `slider-item ${index === 0 ? 'active' : ''}`;
                slideElement.innerHTML = `
                    <div class="slider-bg" style="background: linear-gradient(135deg, rgba(26, 95, 63, 0.85), rgba(13, 61, 40, 0.85)), url('${slide.image_path}') center/cover;"></div>
                `;
                sliderContainer.appendChild(slideElement);
            });
        },
        
        renderDots: function() {
            const dotsContainer = document.getElementById('sliderDots');
            dotsContainer.innerHTML = '';
            
            this.slides.forEach((slide, index) => {
                const dot = document.createElement('span');
                dot.className = `dot ${index === 0 ? 'active' : ''}`;
                dot.setAttribute('data-slide', index);
                dot.addEventListener('click', () => this.goToSlide(index));
                dotsContainer.appendChild(dot);
            });
        },
        
        setupControls: function() {
            const prevBtn = document.getElementById('sliderPrev');
            const nextBtn = document.getElementById('sliderNext');
            
            if (prevBtn) prevBtn.addEventListener('click', () => this.prevSlide());
            if (nextBtn) nextBtn.addEventListener('click', () => this.nextSlide());
        },
        
        goToSlide: function(index) {
            const slides = document.querySelectorAll('.slider-item');
            const dots = document.querySelectorAll('.dot');
            
            // Remove active class from all
            slides.forEach(slide => slide.classList.remove('active'));
            dots.forEach(dot => dot.classList.remove('active'));
            
            // Add active class to current
            if (slides[index]) slides[index].classList.add('active');
            if (dots[index]) dots[index].classList.add('active');
            
            this.currentSlide = index;
            this.resetAutoplay();
        },
        
        nextSlide: function() {
            const nextIndex = (this.currentSlide + 1) % this.slides.length;
            this.goToSlide(nextIndex);
        },
        
        prevSlide: function() {
            const prevIndex = (this.currentSlide - 1 + this.slides.length) % this.slides.length;
            this.goToSlide(prevIndex);
        },
        
        startAutoplay: function() {
            if (this.slides.length > 1) {
                this.autoplayInterval = setInterval(() => {
                    this.nextSlide();
                }, this.autoplayDelay);
            }
        },
        
        stopAutoplay: function() {
            if (this.autoplayInterval) {
                clearInterval(this.autoplayInterval);
            }
        },
        
        resetAutoplay: function() {
            this.stopAutoplay();
            this.startAutoplay();
        }
    };
    
    // Initialize slider
    heroSlider.init();
    
    // Pause autoplay on hover
    const heroSection = document.querySelector('.hero');
    if (heroSection) {
        heroSection.addEventListener('mouseenter', () => heroSlider.stopAutoplay());
        heroSection.addEventListener('mouseleave', () => heroSlider.startAutoplay());
    }
    
    // ============================
    // NAVBAR FUNCTIONALITY
    // ============================
    
    const navbar = document.getElementById('navbar');
    const menuToggle = document.getElementById('menuToggle');
    const navMenu = document.getElementById('navMenu');
    
    // Navbar scroll effect
    window.addEventListener('scroll', function() {
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    });
    
    // Mobile menu toggle
    menuToggle.addEventListener('click', function() {
        navMenu.classList.toggle('active');
        
        // Animate hamburger menu
        const spans = menuToggle.querySelectorAll('span');
        if (navMenu.classList.contains('active')) {
            spans[0].style.transform = 'rotate(45deg) translateY(6px)';
            spans[1].style.opacity = '0';
            spans[2].style.transform = 'rotate(-45deg) translateY(-6px)';
        } else {
            spans[0].style.transform = 'none';
            spans[1].style.opacity = '1';
            spans[2].style.transform = 'none';
        }
    });
    
    // Close menu when clicking nav links
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', function() {
            navMenu.classList.remove('active');
            const spans = menuToggle.querySelectorAll('span');
            spans[0].style.transform = 'none';
            spans[1].style.opacity = '1';
            spans[2].style.transform = 'none';
        });
    });
    
    // ============================
    // SMOOTH SCROLLING
    // ============================
    
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            
            if (target) {
                const offsetTop = target.offsetTop - 80;
                window.scrollTo({
                    top: offsetTop,
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // ============================
    // SCROLL ANIMATIONS
    // ============================
    
    const observerOptions = {
        threshold: 0.15,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                
                // Add stagger delay for children
                const children = entry.target.querySelectorAll('.feature-card, .service-card, .why-card');
                children.forEach((child, index) => {
                    setTimeout(() => {
                        child.style.opacity = '1';
                        child.style.transform = 'translateY(0)';
                    }, index * 100);
                });
            }
        });
    }, observerOptions);
    
    // Observe sections
    const sections = document.querySelectorAll('.about, .features, .why-us, .services, .cta');
    sections.forEach(section => {
        section.classList.add('scroll-animate');
        observer.observe(section);
    });
    
    // ============================
    // COUNTER ANIMATION
    // ============================
    
    function animateCounter(element, target, duration = 2000) {
        let start = 0;
        const increment = target / (duration / 16);
        const isPercentage = target.toString().includes('.');
        
        const timer = setInterval(() => {
            start += increment;
            if (start >= target) {
                start = target;
                clearInterval(timer);
            }
            
            if (isPercentage) {
                element.textContent = start.toFixed(1) + '%';
            } else if (target >= 1000) {
                element.textContent = Math.floor(start).toLocaleString() + '+';
            } else {
                element.textContent = Math.floor(start).toLocaleString();
            }
        }, 16);
    }
    
    // Observe stats for counter animation
    const statsObserver = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting && !entry.target.classList.contains('counted')) {
                entry.target.classList.add('counted');
                const statNumbers = entry.target.querySelectorAll('.stat-number');
                
                statNumbers.forEach(stat => {
                    const text = stat.textContent;
                    let targetValue;
                    
                    if (text.includes('%')) {
                        targetValue = parseFloat(text);
                    } else if (text.includes('K')) {
                        targetValue = parseInt(text) * 1000;
                    } else {
                        targetValue = parseInt(text);
                    }
                    
                    stat.textContent = '0';
                    setTimeout(() => {
                        animateCounter(stat, targetValue);
                    }, 500);
                });
            }
        });
    }, { threshold: 0.5 });
    
    const heroStats = document.querySelector('.hero-stats');
    if (heroStats) {
        statsObserver.observe(heroStats);
    }
    
    // ============================
    // PARALLAX EFFECT
    // ============================
    
    window.addEventListener('scroll', function() {
        const scrolled = window.pageYOffset;
        
        // Parallax for hero background
        const heroPattern = document.querySelector('.hero-pattern');
        if (heroPattern) {
            heroPattern.style.transform = `translateY(${scrolled * 0.5}px)`;
        }
        
        // Parallax for mosque illustration
        const mosqueIllustration = document.querySelector('.mosque-illustration');
        if (mosqueIllustration) {
            mosqueIllustration.style.transform = `translateY(${scrolled * 0.2}px)`;
        }
    });
    
    // ============================
    // TYPING EFFECT (Optional)
    // ============================
    
    function typeWriter(element, text, speed = 100) {
        let i = 0;
        element.textContent = '';
        
        function type() {
            if (i < text.length) {
                element.textContent += text.charAt(i);
                i++;
                setTimeout(type, speed);
            }
        }
        
        type();
    }
    
    // ============================
    // HOVER EFFECTS
    // ============================
    
    // Card tilt effect on hover
    const cards = document.querySelectorAll('.feature-card, .service-card, .why-card');
    
    cards.forEach(card => {
        card.addEventListener('mousemove', function(e) {
            const rect = card.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            const centerX = rect.width / 2;
            const centerY = rect.height / 2;
            
            const rotateX = (y - centerY) / 20;
            const rotateY = (centerX - x) / 20;
            
            card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-8px)`;
        });
        
        card.addEventListener('mouseleave', function() {
            card.style.transform = 'perspective(1000px) rotateX(0) rotateY(0) translateY(0)';
        });
    });
    
    // ============================
    // LOADING ANIMATION
    // ============================
    
    window.addEventListener('load', function() {
        document.body.classList.add('loaded');
        
        // Trigger hero animation
        const heroContent = document.querySelector('.hero-content');
        if (heroContent) {
            heroContent.style.animation = 'fadeInUp 1s ease-out';
        }
    });
    
    // ============================
    // BUTTON RIPPLE EFFECT
    // ============================
    
    const buttons = document.querySelectorAll('.btn');
    
    buttons.forEach(button => {
        button.addEventListener('click', function(e) {
            const ripple = document.createElement('span');
            const rect = this.getBoundingClientRect();
            const size = Math.max(rect.width, rect.height);
            const x = e.clientX - rect.left - size / 2;
            const y = e.clientY - rect.top - size / 2;
            
            ripple.style.width = ripple.style.height = size + 'px';
            ripple.style.left = x + 'px';
            ripple.style.top = y + 'px';
            ripple.classList.add('ripple');
            
            this.appendChild(ripple);
            
            setTimeout(() => {
                ripple.remove();
            }, 600);
        });
    });
    
    // Add ripple styles
    const style = document.createElement('style');
    style.textContent = `
        .btn {
            position: relative;
            overflow: hidden;
        }
        
        .ripple {
            position: absolute;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.5);
            transform: scale(0);
            animation: rippleEffect 0.6s ease-out;
            pointer-events: none;
        }
        
        @keyframes rippleEffect {
            to {
                transform: scale(4);
                opacity: 0;
            }
        }
    `;
    document.head.appendChild(style);
    
    // ============================
    // LAZY LOADING IMAGES
    // ============================
    
    if ('IntersectionObserver' in window) {
        const imageObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    if (img.dataset.src) {
                        img.src = img.dataset.src;
                        img.removeAttribute('data-src');
                    }
                    observer.unobserve(img);
                }
            });
        });
        
        const images = document.querySelectorAll('img[data-src]');
        images.forEach(img => imageObserver.observe(img));
    }
    
    // ============================
    // MOUSE CURSOR CUSTOM EFFECT (Optional)
    // ============================
    
    const cursor = document.createElement('div');
    cursor.classList.add('custom-cursor');
    document.body.appendChild(cursor);
    
    const cursorFollower = document.createElement('div');
    cursorFollower.classList.add('cursor-follower');
    document.body.appendChild(cursorFollower);
    
    let mouseX = 0, mouseY = 0;
    let cursorX = 0, cursorY = 0;
    
    document.addEventListener('mousemove', function(e) {
        mouseX = e.clientX;
        mouseY = e.clientY;
        
        cursor.style.left = mouseX + 'px';
        cursor.style.top = mouseY + 'px';
    });
    
    // Smooth follower animation
    function animateCursor() {
        const dx = mouseX - cursorX;
        const dy = mouseY - cursorY;
        
        cursorX += dx * 0.1;
        cursorY += dy * 0.1;
        
        cursorFollower.style.left = cursorX + 'px';
        cursorFollower.style.top = cursorY + 'px';
        
        requestAnimationFrame(animateCursor);
    }
    
    animateCursor();
    
    // Cursor hover effects
    const interactiveElements = document.querySelectorAll('a, button, .btn');
    interactiveElements.forEach(el => {
        el.addEventListener('mouseenter', function() {
            cursor.classList.add('active');
            cursorFollower.classList.add('active');
        });
        
        el.addEventListener('mouseleave', function() {
            cursor.classList.remove('active');
            cursorFollower.classList.remove('active');
        });
    });
    
    // Add cursor styles
    const cursorStyle = document.createElement('style');
    cursorStyle.textContent = `
        .custom-cursor,
        .cursor-follower {
            position: fixed;
            pointer-events: none;
            z-index: 9999;
            border-radius: 50%;
            transition: transform 0.2s ease-out, opacity 0.2s;
        }
        
        .custom-cursor {
            width: 10px;
            height: 10px;
            background: var(--accent-color);
            transform: translate(-50%, -50%);
        }
        
        .cursor-follower {
            width: 40px;
            height: 40px;
            border: 2px solid var(--accent-color);
            transform: translate(-50%, -50%);
            opacity: 0.5;
        }
        
        .custom-cursor.active {
            transform: translate(-50%, -50%) scale(0.5);
        }
        
        .cursor-follower.active {
            transform: translate(-50%, -50%) scale(1.5);
        }
        
        @media (max-width: 768px) {
            .custom-cursor,
            .cursor-follower {
                display: none;
            }
        }
    `;
    document.head.appendChild(cursorStyle);
    
    // ============================
    // CONSOLE LOG
    // ============================
    
    console.log('%c MDN - Masjid Digital Network ', 'background: #1a5f3f; color: #d4af37; font-size: 20px; padding: 10px;');
    console.log('%c Website berhasil dimuat! ', 'color: #1a5f3f; font-size: 14px;');
    
});

// ============================
// UTILITY FUNCTIONS
// ============================

// Scroll to top function
function scrollToTop() {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
}

// Check if element is in viewport
function isInViewport(element) {
    const rect = element.getBoundingClientRect();
    return (
        rect.top >= 0 &&
        rect.left >= 0 &&
        rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
        rect.right <= (window.innerWidth || document.documentElement.clientWidth)
    );
}

// Debounce function for performance
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}