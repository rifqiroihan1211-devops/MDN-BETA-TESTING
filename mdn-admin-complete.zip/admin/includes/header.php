<?php
/**
 * MDN Admin - Header
 */
if (!defined('ADMIN_PAGE')) {
    die('Access denied');
}

// Check if user is logged in
if (!is_logged_in()) {
    redirect(ADMIN_URL . 'login.php');
}

$current_page = basename($_SERVER['PHP_SELF'], '.php');
$admin_name = $_SESSION['full_name'] ?? 'Admin';
$admin_role = $_SESSION['role'] ?? 'admin';
$admin_avatar = $_SESSION['avatar'] ?? null;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title ?? 'Dashboard' ?> - MDN Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/admin.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
</head>
<body>
    <div class="admin-wrapper">
        <!-- Sidebar -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <div class="logo-icon">🕌</div>
                    <span class="logo-text">MDN Admin</span>
                </div>
                <button class="sidebar-toggle" id="sidebarToggle">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
            </div>
            
            <nav class="sidebar-nav">
                <ul class="nav-list">
                    <li class="nav-item">
                        <a href="index.php" class="nav-link <?= $current_page === 'index' ? 'active' : '' ?>">
                            <span class="nav-icon">📊</span>
                            <span class="nav-text">Dashboard</span>
                        </a>
                    </li>
                    
                    <?php if ($admin_role === 'super_admin'): ?>
                    <li class="nav-section">Landing Page</li>
                    
                    <li class="nav-item">
                        <a href="hero-settings.php" class="nav-link <?= $current_page === 'hero-settings' ? 'active' : '' ?>">
                            <span class="nav-icon">🎯</span>
                            <span class="nav-text">Hero Section</span>
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <a href="sliders.php" class="nav-link <?= $current_page === 'sliders' ? 'active' : '' ?>">
                            <span class="nav-icon">🖼️</span>
                            <span class="nav-text">Slider Gambar</span>
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <a href="about-settings.php" class="nav-link <?= $current_page === 'about-settings' ? 'active' : '' ?>">
                            <span class="nav-icon">ℹ️</span>
                            <span class="nav-text">Tentang Kami</span>
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <a href="features.php" class="nav-link <?= $current_page === 'features' ? 'active' : '' ?>">
                            <span class="nav-icon">⚡</span>
                            <span class="nav-text">Fitur</span>
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <a href="contact-settings.php" class="nav-link <?= $current_page === 'contact-settings' ? 'active' : '' ?>">
                            <span class="nav-icon">📞</span>
                            <span class="nav-text">Kontak & Sosmed</span>
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <li class="nav-section">Konten</li>
                    
                    <li class="nav-item">
                        <a href="services.php" class="nav-link <?= $current_page === 'services' ? 'active' : '' ?>">
                            <span class="nav-icon">🛠️</span>
                            <span class="nav-text">Layanan</span>
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <a href="offices.php" class="nav-link <?= $current_page === 'offices' ? 'active' : '' ?>">
                            <span class="nav-icon">🏢</span>
                            <span class="nav-text">Kantor</span>
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <a href="gallery.php" class="nav-link <?= $current_page === 'gallery' ? 'active' : '' ?>">
                            <span class="nav-icon">🎨</span>
                            <span class="nav-text">Galeri</span>
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <a href="faq.php" class="nav-link <?= $current_page === 'faq' ? 'active' : '' ?>">
                            <span class="nav-icon">❓</span>
                            <span class="nav-text">FAQ</span>
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <a href="messages.php" class="nav-link <?= $current_page === 'messages' ? 'active' : '' ?>">
                            <span class="nav-icon">✉️</span>
                            <span class="nav-text">Pesan Masuk</span>
                            <?php
                            try {
                                $db = Database::getInstance()->getConnection();
                                $stmt = $db->query("SELECT COUNT(*) as count FROM contact_messages WHERE status = 'new'");
                                $unread = $stmt->fetch()['count'];
                                if ($unread > 0) {
                                    echo '<span class="badge">' . $unread . '</span>';
                                }
                            } catch (Exception $e) {}
                            ?>
                        </a>
                    </li>
                    
                    <?php if ($admin_role === 'super_admin'): ?>
                    <li class="nav-section">Sistem</li>
                    
                    <li class="nav-item">
                        <a href="admins.php" class="nav-link <?= $current_page === 'admins' ? 'active' : '' ?>">
                            <span class="nav-icon">👥</span>
                            <span class="nav-text">Kelola Admin</span>
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <a href="activity-logs.php" class="nav-link <?= $current_page === 'activity-logs' ? 'active' : '' ?>">
                            <span class="nav-icon">📝</span>
                            <span class="nav-text">Log Aktivitas</span>
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
            </nav>
            
            <div class="sidebar-footer">
                <div class="admin-info">
                    <div class="admin-avatar">
                        <?php if ($admin_avatar): ?>
                            <img src="<?= UPLOAD_URL . $admin_avatar ?>" alt="<?= $admin_name ?>">
                        <?php else: ?>
                            <span><?= substr($admin_name, 0, 1) ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="admin-details">
                        <div class="admin-name"><?= $admin_name ?></div>
                        <div class="admin-role"><?= $admin_role === 'super_admin' ? 'Super Admin' : 'Admin' ?></div>
                    </div>
                </div>
            </div>
        </aside>
        
        <!-- Main Content -->
        <div class="main-content">
            <!-- Top Bar -->
            <header class="topbar">
                <div class="topbar-left">
                    <button class="mobile-menu-toggle" id="mobileMenuToggle">
                        <span></span>
                        <span></span>
                        <span></span>
                    </button>
                    <h1 class="page-title"><?= $page_title ?? 'Dashboard' ?></h1>
                </div>
                
                <div class="topbar-right">
                    <a href="<?= BASE_URL ?>" target="_blank" class="btn-preview" title="Lihat Website">
                        <span>🌐</span>
                        <span class="text">Lihat Website</span>
                    </a>
                    
                    <div class="dropdown profile-dropdown">
                        <button class="dropdown-toggle" id="profileDropdown">
                            <div class="profile-avatar">
                                <?php if ($admin_avatar): ?>
                                    <img src="<?= UPLOAD_URL . $admin_avatar ?>" alt="<?= $admin_name ?>">
                                <?php else: ?>
                                    <span><?= substr($admin_name, 0, 1) ?></span>
                                <?php endif; ?>
                            </div>
                            <span class="dropdown-arrow">▼</span>
                        </button>
                        <div class="dropdown-menu" id="profileMenu">
                            <a href="profile.php" class="dropdown-item">
                                <span>👤</span> Profil Saya
                            </a>
                            <a href="settings.php" class="dropdown-item">
                                <span>⚙️</span> Pengaturan
                            </a>
                            <div class="dropdown-divider"></div>
                            <a href="logout.php" class="dropdown-item text-danger">
                                <span>🚪</span> Logout
                            </a>
                        </div>
                    </div>
                </div>
            </header>
            
            <!-- Page Content -->
            <div class="page-content">
